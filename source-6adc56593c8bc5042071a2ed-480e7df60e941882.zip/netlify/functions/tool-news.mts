// Returns this month's news headlines for a single AI tool listed in the directory.
// Only known tools are accepted so the endpoint can't be used as a general search proxy.
const QUERIES: Record<string, string> = {
  "chatgpt": '"ChatGPT"',
  "google-gemini": '"Google Gemini" OR "Gemini AI"',
  "claude": '"Claude" Anthropic',
  "grammarly": '"Grammarly"',
  "canva": '"Canva" AI',
  "adobe-firefly": '"Adobe Firefly"',
  "microsoft-designer": '"Microsoft Designer"',
  "capcut": '"CapCut"',
  "elevenlabs": '"ElevenLabs"',
  "github-copilot": '"GitHub Copilot"',
  "replit": '"Replit"',
  "cursor": '"Cursor" AI code editor OR Anysphere',
  "perplexity": '"Perplexity AI" OR "Perplexity" Comet OR "Perplexity" search engine',
  "notion-ai": '"Notion AI" OR "Notion Labs" OR "Notion" workspace',
};

const MAX_ITEMS = 8;

function decode(text: string) {
  return text
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .trim();
}

function tag(xml: string, name: string) {
  const match = xml.match(new RegExp(`<${name}[^>]*>([\\s\\S]*?)</${name}>`));
  return match ? decode(match[1]) : "";
}

export default async (req: Request) => {
  const tool = new URL(req.url).searchParams.get("tool") || "";
  const query = QUERIES[tool];
  if (!query) return Response.json({ error: "Unknown tool" }, { status: 400 });

  const now = new Date();
  const monthStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
  const after = monthStart.toISOString().slice(0, 10);
  const feedUrl = `https://news.google.com/rss/search?q=${encodeURIComponent(`${query} after:${after}`)}&hl=en-US&gl=US&ceid=US:en`;

  try {
    const res = await fetch(feedUrl, { headers: { "User-Agent": "Mozilla/5.0 (FreeAITool news)" } });
    if (!res.ok) throw new Error(`Feed responded with ${res.status}`);
    const xml = await res.text();

    const items = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)]
      .map(([, item]) => {
        const source = tag(item, "source");
        let title = tag(item, "title");
        if (source && title.endsWith(` - ${source}`)) title = title.slice(0, -(source.length + 3));
        return { title, url: tag(item, "link"), source, publishedAt: new Date(tag(item, "pubDate")).toISOString() };
      })
      .filter((item) => item.title && item.url.startsWith("https://") && new Date(item.publishedAt) >= monthStart)
      .sort((a, b) => b.publishedAt.localeCompare(a.publishedAt));

    // Prefer headlines that actually name the tool; fall back to everything if there are too few.
    const keywords = [...query.matchAll(/"([^"]+)"/g)].map(([, term]) => term.toLowerCase());
    const named = items.filter((item) => keywords.some((term) => item.title.toLowerCase().includes(term)));
    const relevant = (named.length >= 3 ? named : items).slice(0, MAX_ITEMS);

    return Response.json(
      { tool, month: monthStart.toLocaleString("en-US", { month: "long", year: "numeric", timeZone: "UTC" }), items: relevant },
      {
        headers: {
          "Cache-Control": "public, max-age=600",
          "Netlify-CDN-Cache-Control": "public, durable, s-maxage=3600, stale-while-revalidate=86400",
        },
      },
    );
  } catch (error) {
    console.error("tool-news fetch failed", error);
    return Response.json({ error: "News is temporarily unavailable" }, { status: 502 });
  }
};

export const config = { path: "/api/tool-news" };
